from db import obtener_dataframe


def obtener_resumen_dashboard():

    query = """
        SELECT
            tipo,
            monto
        FROM gastos.movimientos
        WHERE DATE_TRUNC('month', fecha)
              =
              DATE_TRUNC('month', CURRENT_DATE)
    """

    return obtener_dataframe(query)


def obtener_gastos_por_categoria(
    cuenta_id
):

    query = """
    SELECT
        categoria,
        SUM(monto) total
    FROM gastos.movimientos
    WHERE cuenta_id = :cuenta_id
      AND tipo = 'GASTO'
      AND DATE_TRUNC('month', fecha)
          =
          DATE_TRUNC('month', CURRENT_DATE)
    GROUP BY categoria
    ORDER BY total DESC
    """

    return obtener_dataframe(
        query,
        {
            "cuenta_id": cuenta_id
        }
    )

def obtener_tendencia(
    cuenta_id
):

    query = """
    SELECT

        TO_CHAR(
            fecha,
            'YYYY-MM'
        ) mes,

        SUM(
            CASE
                WHEN tipo = 'INGRESO'
                THEN monto
                ELSE 0
            END
        ) ingresos,

        SUM(
            CASE
                WHEN tipo = 'GASTO'
                THEN monto
                ELSE 0
            END
        ) gastos

    FROM gastos.movimientos

    WHERE cuenta_id = :cuenta_id

    GROUP BY
        TO_CHAR(
            fecha,
            'YYYY-MM'
        )

    ORDER BY mes
    """

    return obtener_dataframe(
        query,
        {
            "cuenta_id": cuenta_id
        }
    )