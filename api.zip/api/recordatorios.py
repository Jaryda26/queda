from fastapi import APIRouter
from fastapi import Depends

from api.dependencies import (
    obtener_usuario_actual
)

from api.schemas import (
    RecordatorioCreate
)

from db import obtener_dataframe
from db import ejecutar_query

router = APIRouter(
    prefix="/recordatorios",
    tags=["Recordatorios"]
)


@router.get("/")
def listar_recordatorios(
    usuario=Depends(
        obtener_usuario_actual
    )
):

    query = """
    SELECT
        id,
        descripcion,
        monto,
        fecha_vencimiento,
        pagado,
        tipo
    FROM gastos.recordatorios
    WHERE cuenta_id = :cuenta_id
    ORDER BY fecha_vencimiento
    """

    df = obtener_dataframe(

        query,

        {
            "cuenta_id":
            usuario["cuenta_id"]
        }

    )

    df = df.fillna("")

    return df.to_dict(
        orient="records"
    )


@router.get("/pendientes")
def pendientes(
    usuario=Depends(
        obtener_usuario_actual
    )
):

    query = """
    SELECT
        descripcion
    FROM gastos.recordatorios
    WHERE cuenta_id = :cuenta_id
      AND pagado = FALSE
    """

    df = obtener_dataframe(

        query,

        {
            "cuenta_id":
            usuario["cuenta_id"]
        }

    )

    total = len(df)

    if total == 0:

        return {
            "mensaje":
            "No tienes recordatorios pendientes"
        }

    return {
        "mensaje":
        f"Tienes {total} recordatorios pendientes"
    }


@router.post("/")
def crear_recordatorio(
    recordatorio: RecordatorioCreate,

    usuario=Depends(
        obtener_usuario_actual
    )
):

    query = """
    INSERT INTO gastos.recordatorios
    (
        cuenta_id,
        descripcion,
        tipo,
        pagado
    )
    VALUES
    (
        :cuenta_id,
        :descripcion,
        :tipo,
        FALSE
    )
    """

    ejecutar_query(

        query,

        {

            "cuenta_id":
            usuario["cuenta_id"],

            "descripcion":
            recordatorio.descripcion,

            "tipo":
            recordatorio.tipo,

        }

    )

    return {

        "success": True,

        "mensaje":
        "Recordatorio registrado"

    }


@router.put("/{recordatorio_id}/pagar")
def pagar_recordatorio(
    recordatorio_id: int,

    usuario=Depends(
        obtener_usuario_actual
    )
):

    query = """
    UPDATE gastos.recordatorios
       SET pagado = TRUE,
           fecha_ultimo_pago = CURRENT_DATE
     WHERE id = :id
       AND cuenta_id = :cuenta_id
    """

    ejecutar_query(

        query,

        {

            "id":
            recordatorio_id,

            "cuenta_id":
            usuario["cuenta_id"]

        }

    )

    return {

        "success": True,

        "mensaje":
        "Recordatorio pagado"

    }