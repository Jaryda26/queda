from pydantic import BaseModel


class LoginRequest(BaseModel):
    email: str
    password: str


class LoginResponse(BaseModel):
    access_token: str
    token_type: str
    usuario_id: int
    nombre: str


class MovimientoCreate(BaseModel):
    tipo: str
    concepto: str
    categoria: str
    monto: float


class RecordatorioCreate(BaseModel):
    descripcion: str
    tipo: str