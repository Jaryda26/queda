from fastapi import Header, HTTPException

from api.security import validar_token
from api.user_service import buscar_usuario_por_id


def obtener_usuario_actual(
    authorization: str = Header(None)
):

    if not authorization:

        raise HTTPException(
            status_code=401,
            detail="Token requerido"
        )

    token = authorization.replace(
        "Bearer ",
        ""
    )

    payload = validar_token(token)

    if not payload:

        raise HTTPException(
            status_code=401,
            detail="Token inválido"
        )

    usuario_id = int(
        payload["sub"]
    )

    usuario = buscar_usuario_por_id(
        usuario_id
    )

    if not usuario:

        raise HTTPException(
            status_code=404,
            detail="Usuario no encontrado"
        )

    return usuario