from fastapi import APIRouter, Depends

from api.dependencies import (
    obtener_usuario_actual
)

from api.dashboard_service import (
    obtener_resumen_dashboard,
    obtener_gastos_por_categoria,
    obtener_tendencia
)

router = APIRouter(
    prefix="/dashboard",
    tags=["Dashboard"]
)


@router.get("/resumen")
def resumen():

    df = obtener_resumen_dashboard()

    ingresos = 0
    gastos = 0

    for _, row in df.iterrows():

        tipo = str(
            row["tipo"]
        ).upper()

        monto = float(
            row["monto"]
        )

        if tipo == "INGRESO":

            ingresos += monto

        else:

            gastos += monto

    ahorro = ingresos - gastos

    return {
        "ingresos_mes": ingresos,
        "gastos_mes": gastos,
        "ahorro_mes": ahorro,
        "movimientos": len(df)
    }


@router.get("/categorias")
def categorias(
    usuario=Depends(
        obtener_usuario_actual
    )
):

    df = obtener_gastos_por_categoria(
        usuario["cuenta_id"]
    )

    df = df.fillna("")

    return df.to_dict(
        orient="records"
    )

@router.get("/tendencia")
def tendencia(
    usuario=Depends(
        obtener_usuario_actual
    )
):

    df = obtener_tendencia(
        usuario["cuenta_id"]
    )

    df = df.fillna(0)

    return df.to_dict(
        orient="records"
    )