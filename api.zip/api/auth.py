from fastapi import APIRouter, HTTPException, Query

from api.schemas import LoginRequest
from api.user_service import buscar_usuario
from api.security import crear_token, validar_token

router = APIRouter(
    prefix="/auth",
    tags=["Autenticación"]
)

@router.post("/login")
def login(datos: LoginRequest):

    usuario = buscar_usuario(
        datos.email
    )

    if not usuario:

        raise HTTPException(
            status_code=401,
            detail="Usuario no encontrado"
        )

    token = crear_token({
        "sub": str(usuario["id"])
    })

    return {
        "access_token": token,
        "token_type": "bearer",
        "usuario_id": usuario["id"],
        "nombre": usuario["nombre"]
    }


@router.get("/me")
def me(
    token: str = Query(...)
):

    payload = validar_token(token)

    if not payload:

        raise HTTPException(
            status_code=401,
            detail="Token inválido"
        )

    return payload