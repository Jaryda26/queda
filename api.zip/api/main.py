from fastapi import FastAPI
from api.auth import router as auth_router
from api.dashboard import router as dashboard_router
from api.movimientos import router as movimientos_router
from api.recordatorios import router as recordatorios_router


app = FastAPI(
    title="QUEDA API",
    description="API para Android, iOS y Web",
    version="1.0.0"
)

# Rutas
app.include_router(auth_router)
app.include_router(dashboard_router)
app.include_router(movimientos_router)
app.include_router(recordatorios_router)

@app.get("/")
def root():
    return {
        "sistema": "QUEDA",
        "version": "1.0.0",
        "estado": "online"
    }

@app.get("/health")
def health():
    return {
        "status": "ok"
    }