from db import obtener_dataframe


def buscar_usuario(email):

    query = """
    SELECT
        id,
        nombre,
        email,
        password_hash,
        cuenta_id,
        rol_cuenta
    FROM gastos.usuarios
    WHERE email = :email
    """

    df = obtener_dataframe(
        query,
        {
            "email": email
        }
    )

    if df.empty:
        return None

    return df.iloc[0].to_dict()


def buscar_usuario_por_id(
    usuario_id
):

    query = """
    SELECT
        id,
        nombre,
        email,
        cuenta_id,
        rol_cuenta
    FROM gastos.usuarios
    WHERE id = :usuario_id
    """

    df = obtener_dataframe(
        query,
        {
            "usuario_id": usuario_id
        }
    )

    if df.empty:
        return None

    return df.iloc[0].to_dict()