from fastapi import APIRouter
from fastapi import Depends

from db import obtener_dataframe

from api.schemas import MovimientoCreate
from api.movimientos_service import crear_movimiento

from api.dependencies import (
    obtener_usuario_actual
)

router = APIRouter(
    prefix="/movimientos",
    tags=["Movimientos"]
)


@router.get("/")
def listar_movimientos(
    usuario=Depends(
        obtener_usuario_actual
    )
):

    query = """
        SELECT
            id,
            fecha,
            tipo,
            concepto,
            categoria,
            monto
        FROM gastos.movimientos
        WHERE cuenta_id = :cuenta_id
        ORDER BY fecha DESC
        LIMIT 100
    """

    df = obtener_dataframe(

        query,

        {
            "cuenta_id":
            usuario["cuenta_id"]
        }

    )

    df = df.fillna("")

    return df.to_dict(
        orient="records"
    )


@router.get("/resumen")
def resumen_movimientos(
    usuario=Depends(
        obtener_usuario_actual
    )
):

    query = """
    SELECT

        COALESCE(
            SUM(monto),
            0
        ) total

    FROM gastos.movimientos

    WHERE cuenta_id = :cuenta_id

      AND tipo = 'GASTO'

      AND DATE_TRUNC(
            'month',
            fecha
      ) =
          DATE_TRUNC(
            'month',
            CURRENT_DATE
      )
    """

    df = obtener_dataframe(

        query,

        {
            "cuenta_id":
            usuario["cuenta_id"]
        }

    )

    total = float(
        df.iloc[0]["total"]
    )

    return {

        "mensaje":
        f"Has gastado {total:.2f} pesos este mes"

    }


@router.get("/categoria/{categoria}")
def categoria(
    categoria: str,
    usuario=Depends(
        obtener_usuario_actual
    )
):

    query = """
    SELECT

        COALESCE(
            SUM(monto),
            0
        ) total

    FROM gastos.movimientos

    WHERE cuenta_id = :cuenta_id

      AND tipo = 'GASTO'

      AND LOWER(concepto)
            LIKE :categoria
    """

    df = obtener_dataframe(

        query,

        {
            "cuenta_id":
            usuario["cuenta_id"],

            "categoria":
            f"%{categoria.lower()}%"
        }

    )

    total = float(
        df.iloc[0]["total"]
    )

    return {

        "mensaje":
        f"Has gastado {total:.2f} pesos en {categoria}"

    }


@router.post("/")
def guardar_movimiento(
    movimiento: MovimientoCreate,

    usuario=Depends(
        obtener_usuario_actual
    )
):

    crear_movimiento(

        movimiento.tipo,

        movimiento.concepto,

        movimiento.categoria,

        movimiento.monto,

        usuario["id"],

        usuario["cuenta_id"]

    )

    return {

        "success": True,

        "mensaje":
        "Movimiento registrado"

    }