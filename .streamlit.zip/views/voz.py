import tempfile
import hashlib
import streamlit as st

from services.speech_service import speech_to_text
from services.intent_engine import detectar_intencion
from services.action_engine import ejecutar_accion

from views.asistente import interpretar_movimiento


def pantalla_voz():

    audio_bytes = st.session_state.get(
        "audio_global"
    )

    if not audio_bytes:
        return None

    audio_hash = hashlib.md5(
        audio_bytes
    ).hexdigest()

    if st.session_state.get(
        "ultimo_audio_hash"
    ) == audio_hash:

        return {
            "tipo": "ERROR",
            "mensaje": "⚠ Audio ya procesado."
        }

    st.session_state[
        "ultimo_audio_hash"
    ] = audio_hash

    try:

        with tempfile.NamedTemporaryFile(
            delete=False,
            suffix=".wav"
        ) as tmp:

            tmp.write(audio_bytes)

            archivo_audio = tmp.name

        texto = speech_to_text(
            archivo_audio
        )

        if not texto:

            st.session_state["audio_global"] = None

            return {
                "tipo": "ERROR",
                "mensaje": "⚠ No pude entender el audio."
            }

        st.session_state[
            "ultimo_texto_voz"
        ] = texto

        intencion = detectar_intencion(
            texto
        )

        if intencion:

            intencion["texto_original"] = texto

            accion = intencion.get(
                "accion",
                ""
            )

            # IMPORTANTE:
            # limpiar audio antes del rerun

            if accion in (
                "ABRIR_INICIO",
                "ABRIR_DASHBOARD",
                "ABRIR_RECORDATORIOS"
            ):

                st.session_state[
                    "audio_global"
                ] = None

                ejecutar_accion(
                    intencion
                )

                return {
                    "tipo": "NAVEGACION",
                    "accion": accion
                }

            mensaje = ejecutar_accion(
                intencion
            )

            st.session_state[
                "audio_global"
            ] = None

            return {
                "tipo": "MENSAJE",
                "mensaje": mensaje
            }

        resultado = interpretar_movimiento(
            texto
        )

        resultado[
            "texto_original"
        ] = texto

        mensaje = ejecutar_accion(
            resultado
        )

        st.session_state[
            "audio_global"
        ] = None

        return {
            "tipo": "MENSAJE",
            "mensaje": mensaje
        }

    except Exception as e:

        st.session_state[
            "audio_global"
        ] = None

        return {
            "tipo": "ERROR",
            "mensaje": f"❌ Error: {str(e)}"
        }